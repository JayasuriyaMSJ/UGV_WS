#!/usr/bin/env python3
"""
Complete Simulation Launch File
Launches: Webots World, UGV Controller, Robot State Publisher, and Nav2 Stack
"""

import os
import launch
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from webots_ros2_driver.webots_launcher import WebotsLauncher
from launch.conditions import IfCondition

def generate_launch_description():

    # ===============================
    # PATH DEFINITIONS
    # ===============================
    package_dir = get_package_share_directory('ugv_webots_world')

    # Use our custom RViz config which has the RobotModel QoS fix
    nav2_rviz_config = os.path.join(
        get_package_share_directory('ugv_navigation'),
        'config',
        'ugv_2d.rviz'
    )

    try:
        nav_dir = get_package_share_directory('ugv_navigation')
        nav_launch_path = os.path.join(nav_dir, 'launch', 'navigation.launch.py')
        nav_available = True
    except:
        nav_launch_path = ''
        nav_available = False

    world_path = os.path.join(package_dir, 'worlds', 'ugv_it_office.wbt')
    urdf_path = os.path.join(package_dir, 'urdf', 'ugv.urdf')

    # ===============================
    # LAUNCH ARGUMENTS
    # ===============================
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    enable_nav = LaunchConfiguration('enable_nav', default='true')
    use_slam = LaunchConfiguration('use_slam', default='true')
    map_yaml_file = LaunchConfiguration('map', default='')

    # ===============================
    # WEBOTS ENV
    # ===============================
    if 'WEBOTS_HOME' not in os.environ:
        if os.path.exists('/snap/webots/current/usr/share/webots'):
            os.environ['WEBOTS_HOME'] = '/snap/webots/current/usr/share/webots'

    # ===============================
    # 1. WEBOTS WORLD
    # ===============================
    webots = WebotsLauncher(
        world=world_path,
        mode='realtime',
        ros2_supervisor=False
    )

    # ===============================
    # 2. ROBOT STATE PUBLISHER
    # ===============================
    with open(urdf_path, 'r') as f:
        robot_description = f.read()

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True
        }]
    )

    # ===============================
    # 3. UGV CONTROLLER
    # ===============================
    ugv_controller = Node(
        package='ugv_webots_world',
        executable='ugv_controller_node.py',
        name='ugv_webots_controller',
        output='screen',
        additional_env={'WEBOTS_CONTROLLER_URL': 'tcp://127.0.0.1:1234/ugv_robot'},
        parameters=[{'use_sim_time': True}]
    )

    # ===============================
    # 4. CARTOGRAPHER 2D SLAM
    # ===============================
    cartographer_node = Node(
        package='cartographer_ros',
        executable='cartographer_node',
        name='cartographer_node',
        output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=[
            '-configuration_basename', 'cartographer_config.lua',
            '-configuration_directory', os.path.join(get_package_share_directory('ugv_navigation'), 'config'),
        ],
        remappings=[
            ('scan', '/scan'),
            ('odom', '/odom'),
        ],
        condition=IfCondition(use_slam)
    )

    cartographer_occupancy_grid_node = Node(
        package='cartographer_ros',
        executable='cartographer_occupancy_grid_node',
        name='cartographer_occupancy_grid_node',
        output='screen',
        parameters=[{'use_sim_time': True}],
        condition=IfCondition(use_slam)
    )

    # ===============================
    # 5. NAVIGATION STACK
    # ===============================
    if nav_available:
        navigation = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(nav_launch_path),
            launch_arguments={
                'use_sim_time': use_sim_time,
                'use_slam': use_slam,
                'map': map_yaml_file
            }.items(),
            condition=IfCondition(enable_nav)
        )
    else:
        navigation = launch.actions.LogInfo(
            msg='Navigation package not found. Skipping Nav2.'
        )

    # ===============================
    # 5. RVIZ (MODIFIED — THIS IS THE KEY FIX)
    # ===============================
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', nav2_rviz_config],   # <<< THIS LOADS MAP DISPLAY
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    # ===============================
    # LAUNCH DESCRIPTION
    # ===============================
    return LaunchDescription([

        # --- Launch Arguments
        DeclareLaunchArgument(
            'enable_nav',
            default_value='true',
            description='Enable Navigation stack'
        ),
        DeclareLaunchArgument(
            'use_slam',
            default_value='true',
            description='Use SLAM (true) or load map (false)'
        ),
        DeclareLaunchArgument(
            'map',
            default_value='',
            description='Full path to map yaml file (used when use_slam=false)'
        ),

        # --- Nodes
        webots,
        robot_state_publisher,
        ugv_controller,
        cartographer_node,
        cartographer_occupancy_grid_node,
        navigation,
        rviz,
    ])
